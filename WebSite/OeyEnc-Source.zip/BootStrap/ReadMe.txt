
Required environment for building this project

Tools:
WDK - Windows Driver Kit, used for the build scripts (http://www.microsoft.com/whdc/DevTools/WDK/default.mspx)
WiX - Windows Installer XML (http://wix.sourceforge.net/)

Environtment Variables:
WDKROOT - Path to latest WDK
WIXROOT - Path to the latest WiX installation

Project Dependencies:
None