
Required environment for building this project

Tools:
WDK - Windows Driver Kit, used for the build scripts (http://www.microsoft.com/whdc/DevTools/WDK/default.mspx)

Environtment Variables:
WDKROOT - Path to latest WDK

Project Dependencies:
ObjEx