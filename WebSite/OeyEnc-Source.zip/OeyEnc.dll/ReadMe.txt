
Required environment for building this project

Tools:
WDK - Windows Driver Kit, used for the build scripts (http://www.microsoft.com/whdc/DevTools/WDK/default.mspx)
WSK - Windows SDK, required for pieces missing from the WDK

Environtment Variables:
WDKROOT - Path to latest WDK
WSKROOT - Path to latest WSK

Project Dependencies:
ObjEx
CoJack
InetComm
