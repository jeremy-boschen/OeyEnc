/*
   RemoveSccInfo.js   
   Copyright (C) 2006 Jeremy Boschen. All rights reserved.
   
   Removes source code control information from VS.NET 2003 project files
   
   Usage:
      CSCRIPT.EXE RemoveSccInfo.js "C:\WhateverFolderToScan\"
 */
var oFileSys = WScript.CreateObject('Scripting.FileSystemObject');

/* File extensions for files which should be parsed */ 
var rgExt = [
   /\.sln$/, 
   /\.vcproj$/
];  

/* Start, End tags to search for in each file */
var rgFnd = [
   {Start : /[\t]GlobalSection\(SourceCodeControl\) \= preSolution\r\n/, End : /EndGlobalSection\r\n/, EndLength : 'EndGlobalSection\r\n'.length},
   {Start : /[\t]SccProjectName\=/,  End : /\r\n/, EndLength: 2},
   {Start : /[\t]SccAuxPath\=/,      End : /\r\n/, EndLength: 2},
   {Start : /[\t]SccLocalPath\=/,    End : /\r\n/, EndLength: 2},
   {Start : /[\t]SccProvider\=/,     End : /\r\n/, EndLength: 2}
];

/* Removes items in rgFnd from oFile */
function _ProcessFile( oFile ) {
   WScript.Echo('Removing SCC information from file "' + oFile.Path + '"');
   
   var oStream = oFileSys.OpenTextFile(oFile.Path, 1);
   var sFileTxt = oStream.ReadAll();
   oStream.Close();
   
   for ( var i = 0; i < rgFnd.length; i++ ) {
      var iB = sFileTxt.search(rgFnd[i].Start);
      if ( -1 != iB ) {
         var iE = sFileTxt.substr(iB).search(rgFnd[i].End);
         if ( -1 != iE && Number.NaN != iE ) {
            var sB = sFileTxt.substr(0, iB);
            var sE = sFileTxt.substr(iB + iE + rgFnd[i].EndLength);
            sFileTxt = sB + sE;
         }
      }
   }
   
   /* Overwrite the original file with the new text */
   oFile = oFileSys.CreateTextFile(oFile.Path, true, false);
   oFile.Write(sFileTxt);
   oFile.Close();   
}

/* Enumerates over all files in a folder, then all subfolders */
function _EnumFolder( oFolder ) {
   var oEnum = new Enumerator(oFolder.Files);
   
   while ( !oEnum.atEnd() ) {
      var oFile = oEnum.item();
      /* Check if the file's extention matches those in rgExt */
      for ( var i = 0; i < rgExt.length; i++ ) {
         if ( rgExt[i].test(oFile.Name) ) {
            _ProcessFile(oFile);
         }
      }
      oEnum.moveNext();
   }
   
   oEnum = new Enumerator(oFolder.SubFolders);
   while ( !oEnum.atEnd() ) {
      _EnumFolder(oEnum.item());
      oEnum.moveNext();
   }
}

/* Scan whatever folder was passed in */
_EnumFolder(oFileSys.GetFolder(WScript.Arguments(0)));