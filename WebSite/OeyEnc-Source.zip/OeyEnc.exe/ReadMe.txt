
Required environment for building this project

Tools:
WDK - Windows Driver Kit, used for the build scripts (http://www.microsoft.com/whdc/DevTools/WDK/default.mspx)
WSK - Windows SDK, required for pieces missing from the WDK
WTL - Windows Template Library (http://sourceforge.net/projects/wtl/)

Environtment Variables:
WDKROOT - Path to latest WDK
WSKROOT - Path to latest WSK
WTLROOT - Path to latest WTL

Project Dependencies:
ObjEx
CoJack
InetComm
OeyEnc.dll
